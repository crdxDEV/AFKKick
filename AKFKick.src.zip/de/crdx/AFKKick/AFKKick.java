/*  1:   */ package de.crdx.AFKKick;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import org.bukkit.Bukkit;
/*  6:   */ import org.bukkit.Server;
/*  7:   */ import org.bukkit.command.ConsoleCommandSender;
/*  8:   */ import org.bukkit.entity.Player;
/*  9:   */ import org.bukkit.event.EventHandler;
/* 10:   */ import org.bukkit.event.Listener;
/* 11:   */ import org.bukkit.event.player.PlayerJoinEvent;
/* 12:   */ import org.bukkit.event.player.PlayerQuitEvent;
/* 13:   */ import org.bukkit.plugin.PluginManager;
/* 14:   */ import org.bukkit.plugin.java.JavaPlugin;
/* 15:   */ import org.bukkit.scheduler.BukkitRunnable;
/* 16:   */ 
/* 17:   */ public class AFKKick
/* 18:   */   extends JavaPlugin
/* 19:   */   implements Listener
/* 20:   */ {
/* 21:19 */   ArrayList<AfkSession> list = new ArrayList();
/* 22:   */   public static AFKKick instance;
/* 23:   */   
/* 24:   */   public void onEnable()
/* 25:   */   {
/* 26:24 */     instance = this;
/* 27:25 */     getServer().getPluginManager().registerEvents(this, this);
/* 28:26 */     System.out.println("AFKKick loaded!");
/* 29:27 */     getRunnable().runTaskTimer(this, 0L, 1200L);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void onDisable() {}
/* 33:   */   
/* 34:   */   @EventHandler
/* 35:   */   public void onPlayerJoin(PlayerJoinEvent e)
/* 36:   */   {
/* 37:38 */     Player p = e.getPlayer();
/* 38:39 */     AfkSession newSession = new AfkSession(p);
/* 39:40 */     this.list.add(newSession);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static AFKKick getInstance()
/* 43:   */   {
/* 44:45 */     return instance;
/* 45:   */   }
/* 46:   */   
/* 47:   */   @EventHandler
/* 48:   */   public void onPlayerDisconnect(PlayerQuitEvent e)
/* 49:   */   {
/* 50:51 */     Player p = e.getPlayer();
/* 51:52 */     for (int i = 0; i < this.list.size(); i++)
/* 52:   */     {
/* 53:55 */       AfkSession session = (AfkSession)this.list.get(i);
/* 54:56 */       if (session.getPlayer().getName().equalsIgnoreCase(p.getName())) {
/* 55:58 */         this.list.remove(session);
/* 56:   */       }
/* 57:   */     }
/* 58:   */   }
/* 59:   */   
/* 60:   */   public BukkitRunnable getRunnable()
/* 61:   */   {
/* 62:65 */     new BukkitRunnable()
/* 63:   */     {
/* 64:   */       public void run()
/* 65:   */       {
/* 66:69 */         for (int i = 0; i < AFKKick.this.list.size(); i++)
/* 67:   */         {
/* 68:71 */           AfkSession session = (AfkSession)AFKKick.this.list.get(i);
/* 69:72 */           session.increaseMinute();
/* 70:   */         }
/* 71:74 */         Bukkit.getConsoleSender().sendMessage("§7[§aAfkKick§7] §eNew Minute Countet!");
/* 72:   */       }
/* 73:   */     };
/* 74:   */   }
/* 75:   */ }


/* Location:           C:\Users\Lukas\Desktop\Developing\Server\plugins\AKFKick.jar
 * Qualified Name:     de.crdx.AFKKick.AFKKick
 * JD-Core Version:    0.7.0.1
 */