/*  1:   */ package de.crdx.AFKKick;
/*  2:   */ 
/*  3:   */ import org.bukkit.Bukkit;
/*  4:   */ import org.bukkit.Location;
/*  5:   */ import org.bukkit.entity.Player;
/*  6:   */ import org.bukkit.scheduler.BukkitScheduler;
/*  7:   */ 
/*  8:   */ public class AfkSession
/*  9:   */ {
/* 10:   */   private Player p;
/* 11:   */   private Location lastLoc;
/* 12:   */   private int afkMinutes;
/* 13:   */   
/* 14:   */   public AfkSession(Player p)
/* 15:   */   {
/* 16:20 */     this.p = p;
/* 17:21 */     this.lastLoc = p.getLocation();
/* 18:22 */     this.afkMinutes = 0;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void increaseMinute()
/* 22:   */   {
/* 23:27 */     if ((this.p != null) && (this.p.isOnline())) {
/* 24:29 */       if (!this.p.hasPermission("afkkick.ignore")) {
/* 25:31 */         if (this.lastLoc.distanceSquared(this.p.getLocation()) < 9.0D)
/* 26:   */         {
/* 27:33 */           this.afkMinutes += 1;
/* 28:34 */           this.lastLoc = this.p.getLocation();
/* 29:35 */           if (this.afkMinutes >= 1) {
/* 30:37 */             kickPlayer();
/* 31:   */           }
/* 32:   */         }
/* 33:   */         else
/* 34:   */         {
/* 35:41 */           this.afkMinutes = 0;
/* 36:42 */           this.lastLoc = this.p.getLocation();
/* 37:   */         }
/* 38:   */       }
/* 39:   */     }
/* 40:   */   }
/* 41:   */   
/* 42:   */   private void kickPlayer()
/* 43:   */   {
/* 44:50 */     if (!this.p.hasPermission("autokick.ignore")) {
/* 45:52 */       Bukkit.getScheduler().scheduleSyncDelayedTask(AFKKick.getInstance(), new Runnable()
/* 46:   */       {
/* 47:   */         public void run()
/* 48:   */         {
/* 49:55 */           AfkSession.this.p.kickPlayer("§6>> §eSystem §6| §7You were kicked because of inactivity!");
/* 50:   */         }
/* 51:57 */       }, 20L);
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public Player getPlayer()
/* 56:   */   {
/* 57:64 */     return this.p;
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Lukas\Desktop\Developing\Server\plugins\AKFKick.jar
 * Qualified Name:     de.crdx.AFKKick.AfkSession
 * JD-Core Version:    0.7.0.1
 */