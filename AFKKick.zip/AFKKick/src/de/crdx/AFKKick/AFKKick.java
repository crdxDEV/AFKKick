package de.crdx.AFKKick;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Created by nexotekHD on 21.06.2015.
 */
public class AFKKick extends JavaPlugin implements Listener{

    ArrayList<AfkSession> list = new ArrayList<AfkSession>();
    public static AFKKick instance;

    public void onEnable()
    {
        instance = this;
        getServer().getPluginManager().registerEvents(this,this);
        System.out.println("AFKKick loaded!");
        getRunnable().runTaskTimer(this,0,20 * 60);
    }

    public void onDisable()
    {

    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e)
    {
        Player p = e.getPlayer();
        AfkSession newSession = new AfkSession(p);
        list.add(newSession);
    }

    public static AFKKick getInstance()
    {
        return instance;
    }

    @EventHandler
    public void onPlayerDisconnect(PlayerQuitEvent e)
    {
        Player p = e.getPlayer();
        for(int i = 0;i < list.size();i++)
        {

            AfkSession session = list.get(i);
            if(session.getPlayer().getName().equalsIgnoreCase(p.getName()))
            {
                list.remove(session);
            }
        }
    }

    public BukkitRunnable getRunnable()
    {
        return new BukkitRunnable() {
            @Override
            public void run() {

                for(int i = 0; i < list.size();i++)
                {
                    AfkSession session = list.get(i);
                    session.increaseMinute();
                }
                Bukkit.getConsoleSender().sendMessage("�7[�aAfkKick�7] �eNew Minute Countet!");
            }
        };
    }

}
