package de.crdx.AFKKick;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import de.crdx.AFKKick.AFKKick;

/**
 * Created by crdx.
 */
public class AfkSession {

    private Player p;
    private Location lastLoc;
    private int afkMinutes;

    public AfkSession(Player p)
    {
        this.p = p;
        this.lastLoc = p.getLocation();
        this.afkMinutes = 0;
    }

    public void increaseMinute()
    {
        if(p != null && p.isOnline())
        {
            if(!p.hasPermission("afkkick.ignore"))
            {
                if(lastLoc.distanceSquared(p.getLocation()) < 3 * 3)
                {
                    afkMinutes++;
                    lastLoc = p.getLocation();
                    if(afkMinutes >= 15)
                    {
                        kickPlayer();
                    }
                }else
                {
                    afkMinutes = 0;
                    lastLoc = p.getLocation();
                }

            }
        }
    }
    private void kickPlayer()
    {
        if(!p.hasPermission("autokick.ignore"))
        {
            Bukkit.getScheduler().scheduleSyncDelayedTask(AFKKick.getInstance(), new Runnable() {
                @Override
                public void run() {
                    p.kickPlayer("�6>> �eSystem �6| �7You were kicked because of inactivity!");
                }
            },20L);

        }
    }

    public Player getPlayer()
    {
        return p;
    }


}
